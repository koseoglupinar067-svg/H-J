package com.retrivedmods.wclient.overlay.hud

import android.content.Context
import android.graphics.*
import android.view.View

class ArrayListOverlay(context: Context) : View(context) {
    var isEnabled: Boolean = true
    
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
    }
}