package com.retrivedmods.wclient.game

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.view.KeyEvent
import android.view.accessibility.AccessibilityManager
import android.content.ComponentName
import com.retrivedmods.wclient.service.KitenaKeybindAccessibilityService
import com.retrivedmods.wclient.service.Services

/**
 * Global hardware-key dispatcher. A key can be assigned to any number of modules;
 * every module using the pressed key is toggled together.
 */
object KeybindManager {

    fun handleKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        if (!Services.isActive) return false

        val code = event.keyCode
        if (code == KeyEvent.KEYCODE_UNKNOWN || code == 0) return false

        var toggled = false
        ModuleManager.modules
            .filter { it.keybind == code && !it.private }
            .forEach {
                it.isEnabled = !it.isEnabled
                toggled = true
            }
        return toggled
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        return try {
            val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            val expected = ComponentName(context, KitenaKeybindAccessibilityService::class.java)
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { info -> info.resolveInfo?.serviceInfo?.let { service ->
                    ComponentName(service.packageName, service.name) == expected
                } == true }
        } catch (_: Throwable) {
            false
        }
    }

    fun keyName(keyCode: Int): String {
        if (keyCode == 0) return "NONE"
        return try {
            KeyEvent.keyCodeToString(keyCode)
                .removePrefix("KEYCODE_")
                .replace('_', ' ')
        } catch (_: Throwable) {
            "KEY $keyCode"
        }
    }
}
