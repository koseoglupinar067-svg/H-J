package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.InterceptablePacket

class ArrayListModule : Module("ArrayList", ModuleCategory.values()[0]) {
    var showBackground = true
    var showBorder = true
    var borderStyle = "Left Bar"
    var colorMode = "Normal"
    var rainbowSpeed = 1.0f
    var spacing = 2
    var fadeAnimation = true
    var slideAnimation = true
    var fontStyle = "Minecraft"
    var gradientIntensity = 0.8f
    var glowEffect = false
    var smoothGradient = true
    var position = "Top-Right"
    var customColors = false
    var customRed = 255
    var customGreen = 255
    var customBlue = 255
    var lowercase = false
    var shadow = true
    var suffixMode = "Dash"
    var backgroundAlpha = 150

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }
}