package com.retrivedmods.wclient.overlay.hud

import android.content.Context
import android.graphics.*
import android.view.View

class WaterMarkOverlay(context: Context) : View(context) {
    var isEnabled: Boolean = true
    var customText: String = "Kitena+"
    var currentFps: Int = 60
    var currentPing: Int = 18

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 42f; color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!isEnabled) return
        canvas.drawText(customText + " | " + currentFps + " FPS | " + currentPing + "ms", 24f, 50f, titlePaint)
    }
}