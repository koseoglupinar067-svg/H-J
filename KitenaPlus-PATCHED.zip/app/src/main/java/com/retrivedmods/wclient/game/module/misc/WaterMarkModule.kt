package com.retrivedmods.wclient.game.module.misc

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.InterceptablePacket

class WaterMarkModule : Module("WaterMark", ModuleCategory.values()[0]) {
    var customText = "Kitena+"
    var fontStyle = "Minecraft"
    var colorMode = "Normal"
    var showFps = true
    var showPing = true
    var showServer = false

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }
}