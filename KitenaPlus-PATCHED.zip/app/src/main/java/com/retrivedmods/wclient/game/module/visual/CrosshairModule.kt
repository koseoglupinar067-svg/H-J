package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.overlay.hud.CrosshairOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class CrosshairModule : Module("Crosshair", ModuleCategory.Visual) {

    private var scope: CoroutineScope? = null

    private val crosshairType by enumValue("Type", CrosshairType.CROSS, CrosshairType::class.java)
    private val size by intValue("Size", 10, 4..30)
    private val thickness by intValue("Thickness", 2, 1..10)
    private val gap by intValue("Gap", 3, 0..15)
    private val colorMode by enumValue("Color Mode", ColorMode.STATIC, ColorMode::class.java)
    private val staticColor by enumValue("Static Color", StaticColor.WHITE, StaticColor::class.java)
    private val rainbowSpeed by floatValue("Rainbow Speed", 1.0f, 0.1f..5.0f)
    private val outline by boolValue("Outline", true)
    private val outlineThickness by intValue("Outline Thickness", 1, 1..5)
    private val dynamicColor by boolValue("Dynamic Color", false)
    private val hitMarker by boolValue("Hit Marker", true)
    private val pulsing by boolValue("Pulsing", false)
    private val pulseSpeed by floatValue("Pulse Speed", 1.0f, 0.1f..5.0f)
    private val showHitMarker by boolValue("Show Hit Marker", false)

    override fun onEnabled() {
        super.onEnabled()
        CrosshairOverlay.setOverlayEnabled(true)
        applySettings()

        scope = CoroutineScope(Dispatchers.Main + SupervisorJob()).apply {
            launch {
                while (isEnabled) {
                    applySettings()
                    delay(300L)
                }
            }
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        scope?.cancel()
        scope = null
        CrosshairOverlay.setOverlayEnabled(false)
    }

    override fun onDisconnect(reason: String) {
        scope?.cancel()
        scope = null
        CrosshairOverlay.setOverlayEnabled(false)
    }

    private fun applySettings() {
        CrosshairOverlay.setCrosshairType(crosshairType)
        CrosshairOverlay.setSize(size)
        CrosshairOverlay.setThickness(thickness)
        CrosshairOverlay.setGap(gap)
        CrosshairOverlay.setColorMode(colorMode)
        CrosshairOverlay.setStaticColor(staticColor)
        CrosshairOverlay.setRainbowSpeed(rainbowSpeed)
        CrosshairOverlay.setOutline(outline)
        CrosshairOverlay.setOutlineThickness(outlineThickness)
        CrosshairOverlay.setDynamicColor(dynamicColor)
        CrosshairOverlay.setHitMarker(hitMarker)
        CrosshairOverlay.setPulsing(pulsing)
        CrosshairOverlay.setPulseSpeed(pulseSpeed)
        CrosshairOverlay.setShowHitMarker(showHitMarker)
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }

    enum class CrosshairType {
        CROSS, DOT, CIRCLE, SQUARE, DIAMOND, T_SHAPE, PLUS
    }

    enum class ColorMode {
        STATIC, RAINBOW, HEALTH_BASED, TARGET_BASED, PULSING
    }

    enum class StaticColor {
        WHITE, RED, GREEN, BLUE, YELLOW, CYAN, MAGENTA, ORANGE
    }
}
