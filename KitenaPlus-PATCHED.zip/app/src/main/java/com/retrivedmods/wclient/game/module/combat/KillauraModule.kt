package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.entity.*
import com.retrivedmods.wclient.game.friend.FriendManager
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.cos
import kotlin.math.sin

class KillauraModule : Module("killaura", ModuleCategory.Combat) {

    private var rangeValue by floatValue("range", 7f, 2f..10f)
    private var cpsValue by intValue("cps", 20, 5..30)
    private var packets by intValue("packets", 1, 1..10)
    private var playersOnly by boolValue("players_only", true)
    private var mobsOnly by boolValue("mobs_only", false)
    private var antiBot by boolValue("anti_bot", true)

    // GapSwitch: yemek/gapple eldeyken, hotbar slotunu ekranda değiştirmeden
    // saldırı paketinde uygun silahı kullanır.
    private var gapSwitch by boolValue("GapSwitch", true)


    private var tpAuraEnabled by boolValue("tp_aura", false)
    private var teleportBehind by boolValue("tp_behind", false)
    private var tpSpeed by intValue("tp_speed", 100, 10..500)
    private var tpYOffset by intValue("tp_y_offset", 1, -10..10)
    private var keepDistance by floatValue("keep_distance", 1.2f, 0.5f..10f)


    private var strafe by boolValue("strafe", false)
    private val strafeSpeed by floatValue("strafe_speed", 2.5f, 1f..4f)
    private val strafeRadius by floatValue("strafe_radius", 2.5f, 1f..6f)





    private var lastAttackTime = 0L
    private var tpCooldown = 0L
    private var strafeAngle = 0f



    private fun Player.isBot(): Boolean {

        if (this is LocalPlayer) return false


        val playerListEntry = session.level.playerMap[this.uuid] ?: return true


        val name = playerListEntry.name?.toString() ?: ""
        if (name.isBlank()) return true


        val xuid = playerListEntry.xuid ?: ""
        if (xuid.isEmpty() || xuid == "0") return true

        if (name.trim().isEmpty()) return true

        return false
    }



    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        if (interceptablePacket.packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        val delay = 1000L / cpsValue
        if (now - lastAttackTime < delay) return

        val targets = searchForTargets()
        if (targets.isEmpty()) return

        for (target in targets) {

            if (target is Player && FriendManager.isFriend(target.uuid)) continue

            if (tpAuraEnabled && now - tpCooldown >= tpSpeed) {
                teleportTo(target)
                tpCooldown = now
            }


            repeat(packets) {
                attackWithGapSwitch(target)
            }

            if (strafe) strafeAroundTarget(target)
        }

        lastAttackTime = now
    }


    private fun attackWithGapSwitch(target: Entity) {
        val player = session.localPlayer
        val inv = player.inventory
        val current = inv.hand

        if (!gapSwitch || !isFoodOrGapple(current)) {
            player.attack(target)
            return
        }

        val preferred = if (player.isSwimming) {
            inv.searchForItemIndexedInHotbar { _, item ->
                item.definition?.identifier == "minecraft:trident"
            }
        } else {
            inv.searchForItemIndexedInHotbar { _, item ->
                item.definition?.identifier == "minecraft:netherite_sword"
            } ?: inv.searchForItemIndexedInHotbar { _, item ->
                item.definition?.identifier?.endsWith("_sword") == true
            }
        }

        if (preferred == null) {
            player.attack(target)
            return
        }

        // Server-side equipment state is switched only for the attack packet.
        // Do NOT send PlayerHotbarPacket/clientBound, so the local HUD/selected
        // slot does not visibly change. Restore the original server-side slot
        // immediately after the attack transaction.
        val originalSlot = inv.heldItemSlot
        val selectedItem = inv.content[preferred]

        val equip = MobEquipmentPacket().apply {
            runtimeEntityId = player.runtimeEntityId
            inventorySlot = preferred
            hotbarSlot = preferred
            item = selectedItem
            containerId = 0
        }
        session.serverBound(equip)

        player.swing()
        val attack = InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE_ON_ENTITY
            actionType = 1
            runtimeEntityId = target.runtimeEntityId
            hotbarSlot = preferred
            itemInHand = selectedItem
            playerPosition = player.vec3Position
            clickPosition = Vector3f.ZERO
        }
        session.serverBound(attack)

        if (originalSlot != preferred) {
            val restore = MobEquipmentPacket().apply {
                runtimeEntityId = player.runtimeEntityId
                inventorySlot = originalSlot
                hotbarSlot = originalSlot
                item = inv.content[originalSlot]
                containerId = 0
            }
            session.serverBound(restore)
        }
    }

    private fun isFoodOrGapple(item: org.cloudburstmc.protocol.bedrock.data.inventory.ItemData): Boolean {
        val id = item.definition?.identifier?.lowercase() ?: return false
        return id.contains("apple") || id.contains("bread") ||
            id.contains("beef") || id.contains("porkchop") ||
            id.contains("chicken") || id.contains("mutton") ||
            id.contains("rabbit") || id.contains("cod") ||
            id.contains("salmon") || id.contains("potato") ||
            id.contains("carrot") || id.contains("melon_slice") ||
            id.contains("cookie") || id.contains("pumpkin_pie") ||
            id.contains("stew") || id.contains("chorus_fruit")
    }

    private fun searchForTargets(): List<Entity> {
        val player = session.localPlayer
        return session.level.entityMap.values
            .filter { it.distance(player) <= rangeValue }
            .filter { it.isTarget() }
            .sortedBy { it.distance(player) }
    }

    private fun Entity.isTarget(): Boolean {
        return when (this) {
            is LocalPlayer -> false
            is Player -> {
                if (!playersOnly) return false


                if (antiBot && isBot()) return false

                true
            }
            is EntityUnknown -> mobsOnly && isMob()
            else -> false
        }
    }


    private fun teleportTo(entity: Entity) {
        val player = session.localPlayer
        val pos = entity.vec3Position

        val yawRad = Math.toRadians(entity.vec3Rotation.y.toDouble()).toFloat()
        val behind = Vector3f.from(sin(yawRad), 0f, -cos(yawRad)).normalize()

        val tpPos = if (teleportBehind) {
            Vector3f.from(
                pos.x + behind.x * keepDistance,
                pos.y + tpYOffset,
                pos.z + behind.z * keepDistance
            )
        } else {
            val dir = pos.sub(player.vec3Position).normalize()
            Vector3f.from(
                pos.x - dir.x * keepDistance,
                pos.y + tpYOffset,
                pos.z - dir.z * keepDistance
            )
        }

        session.clientBound(
            MovePlayerPacket().apply {
                runtimeEntityId = player.runtimeEntityId
                position = tpPos
                rotation = entity.vec3Rotation
                mode = MovePlayerPacket.Mode.NORMAL
                onGround = false
                tick = player.tickExists
            }
        )
    }


    private fun strafeAroundTarget(entity: Entity) {
        val pos = entity.vec3Position
        strafeAngle += strafeSpeed
        if (strafeAngle >= 360f) strafeAngle -= 360f

        val x = strafeRadius * cos(strafeAngle)
        val z = strafeRadius * sin(strafeAngle)

        session.clientBound(
            MovePlayerPacket().apply {
                runtimeEntityId = session.localPlayer.runtimeEntityId
                position = pos.add(x.toFloat(), 0f, z.toFloat())
                rotation = Vector3f.ZERO
                mode = MovePlayerPacket.Mode.NORMAL
                onGround = true
                tick = session.localPlayer.tickExists
            }
        )
    }


    private fun EntityUnknown.isMob(): Boolean {
        return this.identifier in MobList.mobTypes
    }
}