package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.InterceptablePacket

class NoHurtCameraModule : Module("NoHurtCamera", ModuleCategory.values()[0]) {
    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }
}