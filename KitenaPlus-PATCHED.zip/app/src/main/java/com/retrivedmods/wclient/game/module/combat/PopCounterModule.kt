package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.TextPacket

class PopCounterModule : Module("Pop Counter", ModuleCategory.Combat) {
    private val announce by boolValue("Announce", true)
    private val counts = HashMap<String, Int>()

    override fun onDisabled() {
        counts.clear()
        super.onDisabled()
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
        if (!isEnabled) return
        val packet = interceptablePacket.packet
        if (packet !is TextPacket) return

        val message = packet.message.toString()
        if (!isPopMessage(message)) return

        val player = extractPlayer(message) ?: return
        val count = (counts[player] ?: 0) + 1
        counts[player] = count

        if (announce) {
            session.displayClientMessage(
                "§a> §f$player §6Totem economy crashed! §f$count pop"
            )
        }
    }

    private fun isPopMessage(message: String): Boolean {
        val m = message.lowercase()
        return (m.contains("popped") || m.contains("pop")) &&
            (m.contains("totem") || m.contains("undying"))
    }

    private fun extractPlayer(message: String): String? {
        val cleaned = message.replace(Regex("§."), "")
        val match = Regex("""^\s*([A-Za-z0-9_]{1,16})\b.*\bpop""", RegexOption.IGNORE_CASE)
            .find(cleaned)
        return match?.groupValues?.getOrNull(1)
    }
}
