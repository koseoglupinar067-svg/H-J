package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.ModuleManager
import com.retrivedmods.wclient.overlay.hud.KeybindsOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class KeybindsModule : Module("Keybinds", ModuleCategory.Visual) {

    private var scope: CoroutineScope? = null

    private val position by enumValue("Position", Position.TOP_LEFT, Position::class.java)
    private val fontSize by intValue("Font Size", 13, 8..24)
    private val showBackground by boolValue("Background", true)

    override fun onEnabled() {
        super.onEnabled()
        KeybindsOverlay.setOverlayEnabled(true)
        applySettings()

        scope = CoroutineScope(Dispatchers.Main + SupervisorJob()).apply {
            launch {
                while (isEnabled) {
                    applySettings()
                    updateBindings()
                    delay(300L)
                }
            }
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        scope?.cancel()
        scope = null
        KeybindsOverlay.setOverlayEnabled(false)
    }

    override fun onDisconnect(reason: String) {
        scope?.cancel()
        scope = null
        KeybindsOverlay.setOverlayEnabled(false)
    }

    private fun applySettings() {
        KeybindsOverlay.setPosition(position)
        KeybindsOverlay.setFontSize(fontSize)
        KeybindsOverlay.setShowBackground(showBackground)
    }

    private fun updateBindings() {
        val bindings = ModuleManager.modules
            .filter { it.keybind != 0 && !it.private }
            .map { KeybindsOverlay.Binding(it.name, it.keybind) }

        KeybindsOverlay.setBindings(bindings)
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }

    enum class Position {
        TOP_LEFT, TOP_CENTER, TOP_RIGHT,
        CENTER_LEFT, CENTER, CENTER_RIGHT,
        BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT
    }
}
