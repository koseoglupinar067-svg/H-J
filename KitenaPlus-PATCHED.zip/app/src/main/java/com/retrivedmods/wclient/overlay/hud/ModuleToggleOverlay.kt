package com.retrivedmods.wclient.overlay.hud

import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.overlay.OverlayWindow
import kotlinx.coroutines.delay

/** Small top-left module status toast: Kitena+ branding, English, RGB text, black background. */
class ModuleToggleOverlay : OverlayWindow() {
    private val _layoutParams by lazy {
        super.layoutParams.apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 12
            y = 48
        }
    }

    override val layoutParams: WindowManager.LayoutParams get() = _layoutParams

    private var visible by mutableStateOf(false)
    private var moduleName by mutableStateOf("")
    private var enabled by mutableStateOf(false)
    private var serial by mutableStateOf(0)

    companion object {
        val overlayInstance by lazy { ModuleToggleOverlay() }

        fun show(name: String, enabled: Boolean) {
            val o = overlayInstance
            o.moduleName = name
            o.enabled = enabled
            o.serial++
            o.visible = true
            try { OverlayManager.showOverlayWindow(o) } catch (_: Throwable) {}
        }
    }

    @Composable
    override fun Content() {
        val currentSerial = serial
        val transition = rememberInfiniteTransition(label = "notificationRgb")
        val hue by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "hue"
        )

        LaunchedEffect(currentSerial) {
            if (currentSerial == 0) return@LaunchedEffect
            visible = true
            delay(1000L)
            visible = false
            delay(260L)
            try { OverlayManager.dismissOverlayWindow(this@ModuleToggleOverlay) } catch (_: Throwable) {}
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(120)) + slideInHorizontally(
                initialOffsetX = { it }, animationSpec = tween(220, easing = FastOutSlowInEasing)
            ),
            exit = fadeOut(tween(220)) + slideOutHorizontally(
                targetOffsetX = { it }, animationSpec = tween(260, easing = FastOutSlowInEasing)
            )
        ) {
            // Use the list-only overload for maximum compatibility with the
            // Compose UI graphics version used by this project.
            // The animated hue is still retained by the notification transition.
            val rgbBrush = Brush.linearGradient(
                colors = listOf(
                    Color.Red, Color.Yellow, Color.Green,
                    Color.Cyan, Color.Blue, Color.Magenta, Color.Red
                )
            )

            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .background(Color.Black)
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "Kitena+",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD54F),
                    modifier = Modifier.padding(bottom = 1.dp)
                )
                Text(
                    text = "$moduleName ${if (enabled) "Enabled" else "Disabled"}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    style = androidx.compose.ui.text.TextStyle(brush = rgbBrush)
                )
            }
        }
    }
}
