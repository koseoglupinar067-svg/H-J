package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.overlay.hud.CoordinatesOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class CoordinatesModule : Module("Coordinates", ModuleCategory.Visual) {

    private var scope: CoroutineScope? = null

    private val showCoordinates by boolValue("Coordinates", true)
    private val showDirection by boolValue("Direction", true)
    private val showDimension by boolValue("Dimension", true)
    private val showSpeed by boolValue("Speed", false)
    private val showNetherCoords by boolValue("Nether Coords", true)
    private val position by enumValue("Position", Position.TOP_LEFT, Position::class.java)
    private val fontSize by intValue("Font Size", 14, 8..24)
    private val colorMode by enumValue("Color Mode", ColorMode.STATIC, ColorMode::class.java)
    private val showBackground by boolValue("Background", true)
    private val backgroundOpacity by floatValue("Background Opacity", 0.7f, 0.0f..1.0f)
    private val showBorder by boolValue("Border", false)
    private val compactMode by boolValue("Compact Mode", false)
    private val precision by intValue("Precision", 1, 0..3)

    override fun onEnabled() {
        super.onEnabled()
        if (!isSessionCreated) return

        CoordinatesOverlay.setOverlayEnabled(true)
        applySettings()

        scope = CoroutineScope(Dispatchers.Main + SupervisorJob()).apply {
            launch {
                while (isEnabled && isSessionCreated) {
                    applySettings()
                    updateCoordinates()
                    delay(100L)
                }
            }
        }
    }

    override fun onDisabled() {
        super.onDisabled()
        scope?.cancel()
        scope = null
        CoordinatesOverlay.setOverlayEnabled(false)
    }

    override fun onDisconnect(reason: String) {
        scope?.cancel()
        scope = null
        CoordinatesOverlay.setOverlayEnabled(false)
    }

    private fun applySettings() {
        CoordinatesOverlay.setShowCoordinates(showCoordinates)
        CoordinatesOverlay.setShowDirection(showDirection)
        CoordinatesOverlay.setShowDimension(showDimension)
        CoordinatesOverlay.setShowSpeed(showSpeed)
        CoordinatesOverlay.setShowNetherCoords(showNetherCoords)
        CoordinatesOverlay.setPosition(position)
        CoordinatesOverlay.setFontSize(fontSize)
        CoordinatesOverlay.setColorMode(colorMode)
        CoordinatesOverlay.setShowBackground(showBackground)
        CoordinatesOverlay.setBackgroundOpacity(backgroundOpacity)
        CoordinatesOverlay.setShowBorder(showBorder)
        CoordinatesOverlay.setCompactMode(compactMode)
        CoordinatesOverlay.setPrecision(precision)
    }

    private fun updateCoordinates() {
        val player = session.localPlayer

        val x = player.posX.toDouble()
        val y = player.posY.toDouble()
        val z = player.posZ.toDouble()
        CoordinatesOverlay.setCoordinates(Triple(x, y, z))

        if (showNetherCoords) {
            CoordinatesOverlay.setNetherCoordinates(Triple(x / 8.0, y, z / 8.0))
        }

        if (showDirection) {
            CoordinatesOverlay.setDirection(directionFromYaw(player.rotationYaw))
        }

        if (showSpeed) {
            val speed = sqrt(
                (player.motionX * player.motionX + player.motionZ * player.motionZ).toDouble()
            ) * 20.0
            CoordinatesOverlay.setSpeed(speed)
        }

        // Dimension change packets aren't tracked here, so this stays on the default.
        CoordinatesOverlay.setDimension("Overworld")
    }

    private fun directionFromYaw(yaw: Float): String {
        val normalized = ((yaw % 360f) + 360f) % 360f
        val directions = arrayOf(
            "South", "Southwest", "West", "Northwest",
            "North", "Northeast", "East", "Southeast"
        )
        val index = (((normalized + 22.5f) / 45f).toInt()) % 8
        return directions[index]
    }

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }

    enum class Position {
        TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, CENTER_LEFT, CENTER_RIGHT
    }

    enum class ColorMode {
        STATIC, RAINBOW, DIMENSION_BASED, SPEED_BASED
    }
}
