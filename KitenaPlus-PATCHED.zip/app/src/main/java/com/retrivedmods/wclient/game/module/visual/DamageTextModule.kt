package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory

/**
 * Placeholder module: nothing in this project currently renders damage-text output
 * (no matching Overlay class), so this only holds config fields for now. It exists
 * so [com.retrivedmods.wclient.game.ModuleManager] compiles; wire it to a HUD overlay
 * before expecting it to show anything on screen.
 */
class DamageTextModule : Module("Damage Text", ModuleCategory.Visual) {
    var showDamageNumbers = true
    var fontSize = 16
    var durationMs = 800

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }
}
