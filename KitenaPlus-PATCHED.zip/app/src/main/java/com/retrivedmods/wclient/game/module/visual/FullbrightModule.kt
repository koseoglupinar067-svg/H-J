package com.retrivedmods.wclient.game.module.visual

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.InterceptablePacket

class FullbrightModule : Module("Fullbright", ModuleCategory.values()[0]) {
    var gammaValue = 100.0f
    
    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }
}