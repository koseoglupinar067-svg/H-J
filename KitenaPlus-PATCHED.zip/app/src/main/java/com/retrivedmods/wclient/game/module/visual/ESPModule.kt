package com.retrivedmods.wclient.game.module.visual

import android.graphics.Canvas
import com.retrivedmods.wclient.game.InterceptablePacket
import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory

/**
 * Compile-time placeholder only.
 *
 * [com.retrivedmods.wclient.render.RenderOverlayView] references this class and calls
 * render(canvas) on every enabled instance it finds. That reference needs a real class
 * to compile against, so this exists - but no through-wall/ESP rendering logic has been
 * implemented here, and this class is intentionally NOT registered in
 * [com.retrivedmods.wclient.game.ModuleManager], so it can never be instantiated or
 * enabled as-is.
 */
class ESPModule : Module("ESP", ModuleCategory.Visual, private = true) {

    override fun beforePacketBound(interceptablePacket: InterceptablePacket) {
    }

    fun render(canvas: Canvas) {
        // Intentionally left blank.
    }
}
