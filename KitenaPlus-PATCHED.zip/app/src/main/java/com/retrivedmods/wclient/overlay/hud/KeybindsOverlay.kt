package com.retrivedmods.wclient.overlay.hud

import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.retrivedmods.wclient.game.KeybindManager
import com.retrivedmods.wclient.game.module.visual.KeybindsModule
import com.retrivedmods.wclient.overlay.OverlayManager
import com.retrivedmods.wclient.overlay.OverlayWindow

/** Dedicated, independently positionable keybind HUD. */
class KeybindsOverlay : OverlayWindow() {
    private val _layoutParams by lazy {
        super.layoutParams.apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 78
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
    }

    override val layoutParams: WindowManager.LayoutParams
        get() = _layoutParams

    data class Binding(val name: String, val keyCode: Int)

    private var bindings by mutableStateOf(listOf<Binding>())
    private var position by mutableStateOf(KeybindsModule.Position.TOP_LEFT)
    private var fontSize by mutableStateOf(13)
    private var showBackground by mutableStateOf(true)
    private var shouldShowOverlay by mutableStateOf(false)

    companion object {
        val overlayInstance by lazy { KeybindsOverlay() }

        fun setOverlayEnabled(enabled: Boolean) {
            overlayInstance.shouldShowOverlay = enabled
            try {
                if (enabled) OverlayManager.showOverlayWindow(overlayInstance)
                else OverlayManager.dismissOverlayWindow(overlayInstance)
            } catch (_: Throwable) {}
        }

        fun setBindings(value: List<Binding>) { overlayInstance.bindings = value }
        fun setPosition(value: KeybindsModule.Position) {
            overlayInstance.position = value
            overlayInstance.updateLayoutParams()
        }
        fun setFontSize(value: Int) { overlayInstance.fontSize = value }
        fun setShowBackground(value: Boolean) { overlayInstance.showBackground = value }
    }

    private fun updateLayoutParams() {
        _layoutParams.gravity = when (position) {
            KeybindsModule.Position.TOP_LEFT -> Gravity.TOP or Gravity.START
            KeybindsModule.Position.TOP_CENTER -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            KeybindsModule.Position.TOP_RIGHT -> Gravity.TOP or Gravity.END
            KeybindsModule.Position.CENTER_LEFT -> Gravity.CENTER_VERTICAL or Gravity.START
            KeybindsModule.Position.CENTER -> Gravity.CENTER
            KeybindsModule.Position.CENTER_RIGHT -> Gravity.CENTER_VERTICAL or Gravity.END
            KeybindsModule.Position.BOTTOM_LEFT -> Gravity.BOTTOM or Gravity.START
            KeybindsModule.Position.BOTTOM_CENTER -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            KeybindsModule.Position.BOTTOM_RIGHT -> Gravity.BOTTOM or Gravity.END
        }
        _layoutParams.x = 20
        _layoutParams.y = 20
        try { windowManager.updateViewLayout(composeView, _layoutParams) } catch (_: Throwable) {}
    }

    @Composable
    override fun Content() {
        if (!shouldShowOverlay || bindings.isEmpty()) return

        val alignEnd = position == KeybindsModule.Position.TOP_RIGHT ||
                position == KeybindsModule.Position.CENTER_RIGHT ||
                position == KeybindsModule.Position.BOTTOM_RIGHT

        Column(
            horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(2.dp),
            modifier = if (showBackground) {
                Modifier.background(Color.Black.copy(alpha = 0.82f)).padding(7.dp)
            } else Modifier.padding(2.dp)
        ) {
            Text(
                text = "KEYBINDS",
                color = Color.White,
                fontSize = (fontSize + 1).sp,
                fontWeight = FontWeight.Bold
            )
            bindings.forEach { binding ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = binding.name,
                        color = Color.White,
                        fontSize = fontSize.sp
                    )
                    Text(
                        text = KeybindManager.keyName(binding.keyCode),
                        color = Color(0xFFFFD54F),
                        fontSize = fontSize.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
