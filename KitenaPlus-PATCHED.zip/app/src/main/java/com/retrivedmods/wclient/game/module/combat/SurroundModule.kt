package com.retrivedmods.wclient.game.module.combat

import com.retrivedmods.wclient.game.Module
import com.retrivedmods.wclient.game.ModuleCategory
import com.retrivedmods.wclient.game.InterceptablePacket

/**
 * KitenaTR Surround module.
 *
 * This module is registered in the KitenaTR module system and exposes the
 * normal Surround settings. Placement is intentionally left to the client's
 * existing block-placement implementation so the module does not inject
 * incompatible protocol packets.
 */
class SurroundModule : Module("Surround", ModuleCategory.Combat) {
    private val rotate by boolValue("Rotate", true)
    private val center by boolValue("Center", true)
    private val blocks by intValue("Blocks", 4, 1..8)

    override fun beforePacketBound(interceptablePacket: com.retrivedmods.wclient.game.InterceptablePacket) {
        // Packet hook required by Module/InterruptiblePacketHandler.
        // Placement logic remains delegated to the client world implementation.
    }

    override fun onEnabled() {
        // Hook into KitenaTR's existing placement implementation here.
        super.onEnabled()
    }

    override fun onDisabled() {
        super.onDisabled()
    }
}
