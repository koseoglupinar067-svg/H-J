package com.retrivedmods.wclient.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.retrivedmods.wclient.game.KeybindManager

/**
 * Receives hardware keys without taking focus away from Minecraft. Returning false
 * lets the original key continue to Minecraft. Keybinds are ignored while an
 * editable chat/input node is focused.
 */
class KitenaKeybindAccessibilityService : AccessibilityService() {

    private var foregroundPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            flags = flags or AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_VIEW_FOCUSED
            // Key events are captured globally; onKeyEvent() itself verifies Minecraft is foreground.
            packageNames = null
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 50
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!isMinecraftForeground()) return false
        if (isTypingInChat()) return false
        KeybindManager.handleKeyEvent(event)
        // Do not consume the key: Minecraft still receives normal movement/action input.
        return false
    }

    private fun isMinecraftForeground(): Boolean {
        val rootPackage = rootInActiveWindow?.packageName?.toString()
        return rootPackage == "com.mojang.minecraftpe" || foregroundPackage == "com.mojang.minecraftpe"
    }

    private fun isTypingInChat(): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        return focused?.isEditable == true
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (event != null && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foregroundPackage = event.packageName?.toString()
        }
    }

    override fun onInterrupt() = Unit
}
